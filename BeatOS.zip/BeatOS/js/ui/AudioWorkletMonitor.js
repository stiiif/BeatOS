// AudioWorklet Performance Monitor
// Functionality has been removed.
export class AudioWorkletMonitor {
    constructor(granularSynth) {
        // No-op
    }
}